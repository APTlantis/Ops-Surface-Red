Red/System [
	Title:   "Red values low-level tokenizer"
	Author:  "Nenad Rakocevic"
	File: 	 %tokenizer.reds
	Tabs:	 4
	Rights:  "Copyright (C) 2017-2018 Red Foundation. All rights reserved."
	License: {
		Distributed under the Boost Software License, Version 1.0.
		See https://github.com/red/red/blob/master/BSL-License.txt
	}
]

tokenizer: context [

	scan-integer: func [
		p		[byte-ptr!]
		len		[integer!]
		unit	[integer!]
		error	[int-ptr!]
		return: [integer!]
		/local
			c	 [integer!]
			n	 [integer!]
			m	 [integer!]
			neg? [logic!]
	][
		neg?: no
		
		c: string/get-char p unit
		if any [
			c = as-integer #"+" 
			c = as-integer #"-"
		][
			neg?: c = as-integer #"-"
			p: p + unit
			len: len - 1
		]
		n: 0
		until [
			c: (string/get-char p unit) - #"0"
			either all [c <= 9 c >= 0][					;-- skip #"'"
				m: n * 10
				if system/cpu/overflow? [error/value: -2 return 0]
				n: m
				if all [neg? n = 2147483640 c = 8][return 80000000h] ;-- special exit trap for -2147483648
				m: n + c
				if system/cpu/overflow? [error/value: -2 return 0]
				n: m
			][
				c: c + #"0"
				either c = as-integer #"'" [0][			;-- pass-thru
					error/value: -1
					len: 1 								;-- force exit
				]
			]
			p: p + unit
			len: len - 1
			zero? len
		]
		either neg? [0 - n][n]
	]

	scan-float: func [
		p		[byte-ptr!]
		len		[integer!]
		unit	[integer!]
		error	[int-ptr!]
		return: [float!]
		/local
			cp	 [integer!]
			tail [byte-ptr!]
			cur	 [byte-ptr!]
			s0	 [byte-ptr!]
	][
		cur: as byte-ptr! "0000000000000000000000000000000"	;-- 32 bytes including NUL
		assert unit <= 4
		tail: p + (len << (unit >> 1))

		if len > 31 [cur: as byte-ptr! system/stack/allocate (len + 1) >> 2 + 1]
		s0: cur

		until [											;-- convert to ascii string
			cp: string/get-char p unit
			if cp <> as-integer #"'" [					;-- skip #"'"
				if cp = as-integer #"," [cp: as-integer #"."]
				cur/1: as-byte cp
				cur: cur + 1
			]
			p: p + unit
			p = tail
		]
		cur/1: #"^@"									;-- replace the byte with null so to-float can use it as end of input

		unless lexer/scan-float s0 s0 + len [error/value: -1 return 1.#NaN]
		string/to-float s0 len error
	]

	scan-tuple: func [
		p		[byte-ptr!]
		len		[integer!]
		unit	[integer!]
		error	[int-ptr!]
		slot	[red-value!]
		/local
			c	 [integer!]
			n	 [integer!]
			m	 [integer!]
			size [integer!]
			tp	 [byte-ptr!]
	][
		tp: (as byte-ptr! slot) + 4
		n: 0
		size: 0
		
		loop len [
			c: string/get-char p unit
			either c = as-integer #"." [
				size: size + 1
				if any [n < 0 n > 255 size > 12][error/value: -1 exit]
				tp/size: as byte! n
				n: 0
			][
				m: n * 10
				if system/cpu/overflow? [error/value: -1 exit]
				n: m
				m: n + c - #"0"
				if system/cpu/overflow? [error/value: -1 exit]
				n: m
			]
			p: p + unit
		]
		size: size + 1									;-- last number
		tp/size: as byte! n
		slot/header: TYPE_TUPLE or (size << 19)
	]

	scan-money: func [
		p		[byte-ptr!]
		len		[integer!]
		unit	[integer!]
		error	[int-ptr!]
		slot	[red-value!]
		/local
			c	 [integer!]
			neg? [logic!]
			s e cur st ds qt [byte-ptr!]
			letter? do-error [subroutine!]
	][
		do-error: [error/value: -1 exit]
		letter?: [
			any [
				all [(as-integer #"A") <= c c <= as-integer #"Z"]
				all [(as-integer #"a") <= c c <= as-integer #"z"]
			]
		]
		if len < 2 [do-error]
		s: p
		e: p + (len * unit)
		c: string/get-char p unit						;-- +/-
		neg?: c = as-integer #"-"
		if any [neg? c = as-integer #"+"][
			p: p + 1
			c: string/get-char p unit
		]

		cur: null
		if letter? [									;-- Currency symbol parsing
			if p + 5 > e [do-error]						;-- minimal money value with currency
			cur: p
			loop 3 [
				c: string/get-char p unit
				unless letter? [do-error]
				p: p + 1
				if p >= e [do-error]
			]
			c: string/get-char p unit
		]
		
		st: p
		either c = as-integer #"$" [					;-- $ processing
			p: p + 1
			if p >= e [do-error]
		][
			if cur <> null [do-error]
			st: st - 1
		]
		
		ds: qt: null
		while [p < e][
			c: string/get-char p unit
			case [
				c = as-integer #"'" [
					if any [
						p - 1 = qt						;-- leading '
						st + 1 = p						;-- $'
						p + 1 = e						;-- ending '
						ds <> null						;-- ' in fraction
					][do-error]
					qt: p
				]
				all [null? ds c = as-integer #"."][		;-- fraction
					ds: p
					if any [
						p - 1 = s						;-- leading .
						p - 1 = st						;-- $.
						p - 1 = qt						;-- '.
						p + 1 = e						;-- ending .
					][do-error]
				]
				true [
					c: c - #"0"
					unless all [0 <= c c <= 9][do-error]
				]
			]
			p: p + 1
		]
		slot: as red-value! money/make-at slot neg? cur st ds e
		if null? slot [do-error]						;-- Currency symbol rejected
	]

]